package br.edu.up.planner

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Devices
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import br.edu.up.planner.ui.screens.projetos.TelaProjetos
import br.edu.up.planner.ui.screens.financas.TelaFinancas
import br.edu.up.planner.ui.screens.tarefas.TarefasNavHost
import kotlinx.coroutines.launch

object PlannerRotas {
    const val TELA_TAREFAS_ROTA = "tela_um"
    const val TELA_PROJETOS_ROTA = "tela_dois"
    const val TELA_FINANCAS_ROTA = "tela_tres"
}

@Preview(device = Devices.PIXEL)
@Composable
fun PlannerNavDrawer() {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val navCtrlDrawer = rememberNavController()

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            DrawerContent(navCtrlDrawer, drawerState)
        },
        content = {
            NavHost(
                navController = navCtrlDrawer,
                startDestination = PlannerRotas.TELA_TAREFAS_ROTA
            ) {
                composable(PlannerRotas.TELA_TAREFAS_ROTA) {
                    TarefasNavHost(drawerState)
                }
                composable(PlannerRotas.TELA_PROJETOS_ROTA) {
                    TelaProjetos(drawerState)
                }
                composable(PlannerRotas.TELA_FINANCAS_ROTA) {
                    TelaFinancas(drawerState)
                }
            }
        }
    )
}

@Composable
private fun DrawerContent(
    navController: NavController,
    drawerState: DrawerState
) {
    val coroutineScope = rememberCoroutineScope()
    val currentBack by navController.currentBackStackEntryAsState()
    val rotaAtual = currentBack?.destination?.route ?: PlannerRotas.TELA_TAREFAS_ROTA

    Column(
        modifier = Modifier
            .width(300.dp)
            .background(Color.White)
            .padding(30.dp)
            .fillMaxHeight()
    ) {
        Spacer(modifier = Modifier.height(70.dp))

        DrawerButton(rotaAtual, PlannerRotas.TELA_TAREFAS_ROTA, "Tarefas", R.drawable.checklist, navController, drawerState)
        DrawerButton(rotaAtual, PlannerRotas.TELA_PROJETOS_ROTA, "Projetos", R.drawable.checklist, navController, drawerState)
        DrawerButton(rotaAtual, PlannerRotas.TELA_FINANCAS_ROTA, "Finanças", R.drawable.checklist, navController, drawerState)
    }
}

@Composable
fun DrawerButton(
    rotaAtual: String,
    rota: String,
    label: String,
    iconId: Int,
    navController: NavController,
    drawerState: DrawerState
) {
    val coroutineScope = rememberCoroutineScope()
    val ehSelecionada = rotaAtual == rota

    TextButton(
        colors = ButtonDefaults.buttonColors(containerColor = getColorMenu(ehSelecionada)),
        onClick = {
            if (rotaAtual != rota) {
                navController.navigate(rota) {
                    popUpTo(rota) { inclusive = true } // Evita múltiplas instâncias
                }
            }
            coroutineScope.launch { drawerState.close() }
        }
    ) {
        Icon(
            painter = painterResource(id = iconId),
            contentDescription = null,
            modifier = Modifier.size(40.dp),
            tint = getColorTexto(ehSelecionada)
        )
        Text(text = label, fontSize = 30.sp, color = getColorTexto(ehSelecionada))
    }
}

fun getColorMenu(estaSelecionada: Boolean): Color {
    return if (estaSelecionada) Color.Yellow else Color.Transparent
}

fun getColorTexto(estaSelecionada: Boolean): Color {
    return if (estaSelecionada) Color.Black else Color.DarkGray
}
